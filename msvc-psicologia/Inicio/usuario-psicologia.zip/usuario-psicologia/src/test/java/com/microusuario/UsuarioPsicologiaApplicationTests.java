package com.microusuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuarioPsicologiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
