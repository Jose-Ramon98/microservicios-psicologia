package com.micropsicologia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroPsicologiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
