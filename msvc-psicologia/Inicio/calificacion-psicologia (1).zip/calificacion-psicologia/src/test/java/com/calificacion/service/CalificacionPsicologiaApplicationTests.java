package com.calificacion.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalificacionPsicologiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
