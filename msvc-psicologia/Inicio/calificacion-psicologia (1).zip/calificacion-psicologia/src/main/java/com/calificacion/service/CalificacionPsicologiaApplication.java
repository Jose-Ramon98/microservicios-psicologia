package com.calificacion.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalificacionPsicologiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalificacionPsicologiaApplication.class, args);
	}

}
